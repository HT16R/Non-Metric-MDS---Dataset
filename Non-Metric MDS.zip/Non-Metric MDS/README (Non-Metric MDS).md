                                                                                          Non-Metric MDS – Magazine Subscribers' Perceptions


Companion dataset for Example 24) in forthcoming textbook ‘Quantitative Media Research’ (Chapter 3 – Measures and Measurement Scales).


A) Content:

   • Raw respondent ratings (n=4) for two magazines (Woman’s Era, Cosmopolitan) on 4 attributes – Price, Graphics, Content, and Utility; using a 7 – point semantic differential scale.

   • Although for simplicity, only four attributes were considered for illustration across two magazines.

   • This dataset contains the responses of the first 4 respondents (x1 – x4) across all six-attribute data, across 12 magazines. 
     
   • The spatial map in figure 21 in the textbook, maps perceptual differences among these 4 respondents across 6 attributes/dimensions – Price, Quality of Paper, Graphics, Content, Presence of Crosswords and Utility;
     for 4 magazines – Woman’s Era, Cosmopolitan, National Geographic and Discover. 

B) Datasets:

   • MDS_Magazine_ Perceptual_Ratings.xlsx – Respondent ratings by the first four respondents (x1 – x4) across 6 attributes/dimensions – Price, Quality of Paper, Graphics, Content, Utility and Presence of Crosswords across 12 magazines. 
     Direct SPSS export (long format with empty cells for non-rated combinations – authentic structure for PROXSCAL).

   • MDS_Magazine_Perceptual_Ratings_Clean.xlsx – Respondent ratings by the first four respondents (x1 – x4) across 6 attributes/dimensions – Price, Quality of Paper, Graphics, Content, Utility and Presence of Crosswords across 12 magazines, with NULL values omitted. 
     Empty cells removed (only actual ratings included – easier for SPSS/beginners).

C) Statistical Analysis:

   • Use with PROXSCAL (SPSS), cmdscale/smacof (R), or similar to reproduce or extend the analysis.
