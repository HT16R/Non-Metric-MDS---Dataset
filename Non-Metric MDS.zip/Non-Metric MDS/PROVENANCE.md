                                                                                          Provenance Statement


-- These datasets were created between January 2023 – December 2023. No generative AI used.  

-- Data procured through primary research and entered manually into SPSS by the author. 